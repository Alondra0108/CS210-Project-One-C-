/*
Alondra Paulino Santos
CS 210
March 23, 2025
Chada Tech Clocks
*/

#ifndef CLOCK_H
#define CLOCK_H

#include <string>
using namespace std;

class Clock {
private:
    unsigned int hour;   // Holds the hour (0-23)
    unsigned int minute; // Holds the minute (0-59)
    unsigned int second; // Holds the second (0-59)

public:
    // Setters
    void setTime(unsigned int h, unsigned int m, unsigned int s);
    void setHour(unsigned int h);
    void setMinute(unsigned int m);
    void setSecond(unsigned int s);

    // Getters
    unsigned int getHour();
    unsigned int getMinute();
    unsigned int getSecond();

    // Time manipulation functions
    void addOneHour();
    void addOneMinute();
    void addOneSecond();
};

// Helper functions declarations
string twoDigitString(unsigned int n);
string nCharString(size_t n, char c);
string formatTime24(unsigned int h, unsigned int m, unsigned int s);
string formatTime12(unsigned int h, unsigned int m, unsigned int s);
unsigned int getMenuChoice(unsigned int maxChoice);
void printMenu();
void displayClocks(unsigned int h, unsigned int m, unsigned int s);
void mainMenu(Clock& c);

#endif
