/*
Alondra Paulino Santos
CS 210
March 23, 2025
Chada Tech Clocks*/

#include "Clock.h"
#include <iostream>
using namespace std;

// Sets entire time at once
void Clock::setTime(unsigned int h, unsigned int m, unsigned int s) {
    hour = h;
    minute = m;
    second = s;
}

// Individual setters
void Clock::setHour(unsigned int h) { hour = h; }
void Clock::setMinute(unsigned int m) { minute = m; }
void Clock::setSecond(unsigned int s) { second = s; }

// Getters
unsigned int Clock::getHour() { return hour; }
unsigned int Clock::getMinute() { return minute; }
unsigned int Clock::getSecond() { return second; }

// Adds one hour, resets to 0 after 23
void Clock::addOneHour() {
    unsigned int hr = getHour();
    if (hr < 23) {
        setHour(hr + 1);
    }
    else {
        setHour(0);
    }
}

// Adds one minute, resets to 0 after 59 and adds an hour
void Clock::addOneMinute() {
    unsigned int min = getMinute();
    if (min < 59) {
        setMinute(min + 1);
    }
    else {
        setMinute(0);
        addOneHour();
    }
}

// Adds one second, resets to 0 after 59 and adds a minute
void Clock::addOneSecond() {
    unsigned int sec = getSecond();
    if (sec < 59) {
        setSecond(sec + 1);
    }
    else {
        setSecond(0);
        addOneMinute();
    }
}

// Adds leading zero if needed, returns 2-digit string
string twoDigitString(unsigned int n) {
    if (n < 10)
        return "0" + to_string(n);
    else
        return to_string(n);
}

// Returns a string of n characters (used for borders/spaces)
string nCharString(size_t n, char c) {
    return string(n, c);
}

// Formats time in 24-hour clock style
string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
    return twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
}

// Formats time in 12-hour clock style with AM/PM
string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
    string ampm = "AM";
    unsigned int twelveHour = h;

    if (h == 0)
        twelveHour = 12;
    else if (h == 12)
        ampm = "PM";
    else if (h > 12) {
        twelveHour = h - 12;
        ampm = "PM";
    }

    return twoDigitString(twelveHour) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + " " + ampm;
}

// Gets user's menu choice and validates input
unsigned int getMenuChoice(unsigned int maxChoice) {
    unsigned int choice = 0;
    while (true) {
        cin >> choice;
        if (cin.fail() || choice < 1 || choice > maxChoice) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please enter a number between 1 and 4: ";
        }
        else {
            break; // Valid input
        }
    }
    return choice;
}

// Prints formatted menu with border and options
void printMenu() {
    const unsigned char width = 26;
    const unsigned int numStrings = 4;
    char* menuOptions[] = {
        (char*)"Add One Hour",
        (char*)"Add One Minute",
        (char*)"Add One Second",
        (char*)"Exit Program"
    };

    cout << nCharString(width, '*') << endl; // Top border

    for (unsigned int i = 0; i < numStrings; i++) {
        string item = menuOptions[i];
        int numberLength = to_string(i + 1).length();
        int contentLength = 2 + numberLength + 2 + item.length();
        int spaceCount = width - contentLength - 1;

        cout << "* " << (i + 1) << "- " << item; // Print option number and text
        cout << nCharString(spaceCount, ' ') << "*" << endl; // Padding spaces + star
    }

    cout << nCharString(width, '*') << endl; // Bottom border
}

// Displays both 12-hour and 24-hour clocks formatted
void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    // Print top border
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;

    // Print clock labels
    cout << "*" << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << "*";
    cout << nCharString(3, ' ') << "*" << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << "*" << endl;

    // Print formatted times
    cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*";
    cout << nCharString(3, ' ') << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << endl;

    // Print bottom border
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
}

// Main menu loop: displays clocks, menu, and handles user choices
void mainMenu(Clock& c) {
    unsigned int choice;
    do {
        displayClocks(c.getHour(), c.getMinute(), c.getSecond()); // Show current clocks
        printMenu(); // Show menu
        cout << "Enter your choice (1-4): ";
        choice = getMenuChoice(4); // Get valid choice

        if (choice == 1)
            c.addOneHour();
        else if (choice == 2)
            c.addOneMinute();
        else if (choice == 3)
            c.addOneSecond();

    } while (choice != 4);

    // Display exit message
    cout << "\nProgram exited. Goodbye!" << endl; // Exit when user selects 4
}
