/*
Alondra Paulino Santos
CS 210
March 23, 2025
Chada Tech Clocks
*/

#include "Clock.h"
#include <iostream>
using namespace std;

int main() {
    Clock myClock; // Create Clock object
    unsigned int hour, minute, second;

    // Get user input for hour with validation
    cout << "Enter starting hour (0-23): ";
    while (!(cin >> hour) || hour > 23) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Invalid input. Please enter starting hour (0-23): ";
    }

    // Get user input for minute with validation
    cout << "Enter starting minute (0-59): ";
    while (!(cin >> minute) || minute > 59) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Invalid input. Please enter starting minute (0-59): ";
    }

    // Get user input for second with validation
    cout << "Enter starting second (0-59): ";
    while (!(cin >> second) || second > 59) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Invalid input. Please enter starting second (0-59): ";
    }

    // Set initial time in Clock object
    myClock.setTime(hour, minute, second);

    // Start main menu loop
    mainMenu(myClock);

    return 0;
}
